<?php
include 'conn.php';

if(isset($_POST["sub"])){
    $name = $_POST["name"];
    $email = $_POST["email"];
    $comments = $_POST["comments"];

 $sql = "INSERT INTO `index_01` (`name`, `email`, `comments`, `created_at`) 
 VALUES ( '$name', '$email', '$comments', current_timestamp())";
 //echo $sql;

 $res = mysqli_query($conn,$sql);
   if($res){
     //echo "successfully inserted";
    }else{
       echo "sorry unsuccessfull";
   }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'nav.php' ?>

<div class="container">


<?php
    $sql = "select * from `index_01`";
    $result = mysqli_query($conn, $sql);
    if ($result) {
       // echo "successfully";
        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
            $name = $row['name'];
            $email = $row['email'];
            $comments = $row["comments"];

          // echo $id;
        }
    }
    else
    {
       echo "unsuccess";
    }
    ?>


  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="img/1.jpg" alt="Los Angeles" style="width:100%;">
      </div>

      <div class="item">
        <img src="img/2.jpg" alt="Chicago" style="width:100%;">
      </div>
      <div class="item">
        <img src="img/3.jpg" alt="New york" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<!-- Container (Aim Section) -->
<div id="portfolio" class="container-fluid text-center bg-grey">
  <h2>Our Aim</h2><br>
  <h4>What we have created</h4>
  <div class="row text-center slideanim">
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/11.jpg" alt="Paris" width="400" height="300">
        <p><strong>Preety</strong></p>
        <p>Yes, we built bond</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/13.jpg" alt="New York" width="400" height="300">
        <p><strong>beauty</strong></p>
        <p>We built trust</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/15.jpg" alt="San Francisco" width="400" height="300">
        <p><strong>Sweety</strong></p>
        <p>Yes, we love travelling</p>
      </div>
    </div>
  </div><br>

<!-- Container (Contact Section) -->

<div id="contact" class="container-fluid bg-grey">
    <h2 class="text-left">CONTACT US</h2>
  <br>
  <br>
  
  <form class="form-horizontal"   method="post">
  <div class="col-md-9" >

      <div class="row">
        <div class="col-sm-5 form-group">
          <input class="form-control" id="name" name="name" placeholder="Name" 
          type="text" required>
        </div>
        <br>
        <br>
        <br>
        <div class= "col-sm-5 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email"
           type="email" required>
        </div>
      </div>
      <br>
      <div class="row">
      <div class= "col-sm-5 form-group">
      <textarea class="form-control" id="comments" name="comments" placeholder
      ="Comment" rows="5"></textarea>
      <br>
      <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary mb-3" 
                    name="sub">Submit</button>
     
  </div>
  
      </div>
    </div>
  </form>
  </div>
  <br>
 

<!-- Footer -->
<footer class="text-center">
  <a class="up-arrow" href="welcome.php" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p> Copyright 2021-2022 by Vaishnavi. All Rights Reserved.</p> 
</footer>
</body>
</html>
