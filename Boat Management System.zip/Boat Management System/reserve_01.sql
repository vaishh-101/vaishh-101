-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2022 at 11:18 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reserve_01`
--

-- --------------------------------------------------------

--
-- Table structure for table `form_01`
--

CREATE TABLE `form_01` (
  `id` int(11) NOT NULL,
  `firstname` varchar(260) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `contactno` int(20) NOT NULL,
  `boat_id` int(10) NOT NULL,
  `members` int(10) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `form_01`
--

INSERT INTO `form_01` (`id`, `firstname`, `lastname`, `contactno`, `boat_id`, `members`, `created_at`) VALUES
(1, ' arti ', 'warghude', 2147483647, 1, 65, '2022-05-20 14:27:37'),
(2, ' arti ', 'warghude', 2147483647, 1, 65, '2022-05-20 14:28:06'),
(3, ' arti ', 'warghude', 2147483647, 1, 65, '2022-05-20 14:28:46'),
(4, ' arti ', 'warghude', 2147483647, 1, 65, '2022-05-20 14:29:04');

-- --------------------------------------------------------

--
-- Table structure for table `index_01`
--

CREATE TABLE `index_01` (
  `id` int(11) NOT NULL,
  `name` varchar(260) NOT NULL,
  `email` varchar(250) NOT NULL,
  `comments` varchar(500) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `index_01`
--

INSERT INTO `index_01` (`id`, `name`, `email`, `comments`, `created_at`) VALUES
(8, 'w', 'w@g.com', '123121', '2022-05-20 11:41:28');

-- --------------------------------------------------------

--
-- Table structure for table `sign_01`
--

CREATE TABLE `sign_01` (
  `id` int(11) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sign_01`
--

INSERT INTO `sign_01` (`id`, `fullname`, `email`, `password`, `created_at`) VALUES
(18, '', '', '', '2022-05-20 12:30:09'),
(19, '', '', '', '2022-05-20 12:31:05'),
(20, '', '', '', '2022-05-20 13:53:16'),
(21, '', '', '', '2022-05-20 13:56:08'),
(22, '', '', '', '2022-05-20 13:57:07'),
(23, '', '', '', '2022-05-20 13:59:22'),
(24, '', '', '', '2022-05-20 14:00:31'),
(25, '', '', '', '2022-05-20 14:06:05'),
(26, '', '', '', '2022-05-20 14:12:17'),
(27, 'asdfgh', '123@gmail.com', 'zxcvbnm', '2022-05-20 14:13:38'),
(28, 'arti warghude', 'artiwarghude@gmail.com', '123456', '2022-05-20 14:14:23'),
(29, 'asdfghjkl', 'asdfghj@gmail.com', 'asdfghj', '2022-05-20 14:18:01'),
(30, 'asdfghjkl', 'asdfghj@gmail.com', 'asdfghj', '2022-05-20 14:18:20'),
(31, 'asdfghjkl', 'asdfghj@gmail.com', 'asdfghj', '2022-05-20 14:20:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `form_01`
--
ALTER TABLE `form_01`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `index_01`
--
ALTER TABLE `index_01`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign_01`
--
ALTER TABLE `sign_01`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `form_01`
--
ALTER TABLE `form_01`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `index_01`
--
ALTER TABLE `index_01`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sign_01`
--
ALTER TABLE `sign_01`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
