<?php

include 'conn.php';
if(isset($_POST['firstname']) || isset($_POST['lastname']) || isset($_POST['contactno']) || isset($_POST['boat_id']) || isset($_POST['members'])){
    
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $contactno = $_POST['contactno'];
        $boat_id = $_POST['boat_id'];
        $members = $_POST['members'];
    
        $sql = "INSERT INTO `form_01` (`firstname`, `lastname`, 
        `contactno`, `boat_id`, `members`, `created_at`) 
        VALUES (' $firstname ', '$lastname', '$contactno', '$boat_id', '$members',
         current_timestamp())";
        
        $res = mysqli_query($conn,$sql);
        if($res==true){
           //echo 'successfully inserted';
        }
        else
        {
         echo 'sorry unsuccessfull';
        } 
} 


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title> Online Boat Reservation</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css " />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>
    <?php require 'nav.php' ?>
    <?php
    $sql = "select * from `form_01`";
    $result = mysqli_query($conn, $sql);
    if ($result) {
       //echo "successfully";
        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
            $firstname = $row['firstname'];
            $lastname = $row['lastname'];
            $contactno = $row['contactno'];
            $boat_id = $row['boat_id'];
            $members = $row['members'];
            //echo $id;
        }
    }
    else
    {
        echo 'unsuccessful';
    }

    ?>




    <br>
    <br>
    <br>
    <br>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-4">
                <form method="POST"  enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Firstname</label>
                        <input type="text" class="form-control" name="firstname" required="required" />
                    </div>
                    <div class="form-group">
                        <label>Middlename</label>
                        <input type="text" class="form-control" name="middlename" required="required" />
                    </div>
                    <div class="form-group">
                        <label>Lastname</label>
                        <input type="text" class="form-control" name="lastname" required="required" />
                    </div>
                    <div class="form-group">
                        <label>Address</label>
                        <input type="text" class="form-control" name="address" required="required" />
                    </div>
                    <div class="form-group">
                        <label>Contact No</label>
                        <input type="text" class="form-control" name="contactno" required="required" />
                    </div>
                    <div class="form-group">
                        <label>Boat ID</label>
                        <input type="text" class="form-control" name="boat_id" required="required" />
                    </div>
                    <div class="form-group">
                        <label>members</label>
                        <input type="text" class="form-control" name="members" required="required" />
                    </div>
                    <br />
                    <div class="form-group">
                        <button class="btn btn-info form-control" name="sub"><i class="glyphicon glyphicon-save"></i>
                            Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <br>
    <br>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</html>