<!DOCTYPE html>
<html lang="en">

<head>
    <title>Hotel Online Reservation</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>

<body>
 
    <br>
    <br>
    <br>

    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="card" style="width: 28rem;">
                    <img src="boat img/1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">8 Members [1]</h5>
                        <p class="card-text"><b><h5>Rs.100 per person</h5></b></p>
                        <a href="/Boat Management system/reserve_form.php" class="btn btn-primary">Reserve Now</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 28rem;">
                    <img src="boat img/2.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">16 Members [2]</h5>
                        <p class="card-text"><b><h5>Rs.200 per person</h5></b></p>
                        <a href="/Boat Management System/reserve_form.php" class="btn btn-primary">Reserve Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <br>
    <br>
    <br>

    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="card" style="width: 28rem;">
                    <img src="boat img/3.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">24 Members  [3]</h5>
                        <p class="card-text"><b><h5>Rs.300 per person</h5></b></p>
                        <a href="/Boat Management System/reserve_form.php" class="btn btn-primary">Reserve Now</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 28rem;">
                    <img src="boat img/4.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">32 Members[4]</h5>
                        <p class="card-text"><b><h5>Rs.400 per person</h5></b></p>
                        <a href="/Boat Management System/reserve_form.php" class="btn btn-primary">Reserve Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <br>
    <br>
    <br>
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="card" style="width: 28rem;">
                    <img src="boat img/5.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">40 Members [5]</h5>
                        <p class="card-text"><b><h5>Rs.500 per person</h5></b></p>
                        <a href="/Boat Management System/reserve_form.php" class="btn btn-primary">Reserve Now</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card" style="width: 28rem;">
                    <img src="boat img/6.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">48 Members[6]</h5>
                        <p class="card-text"><b><h5>Rs.600 per person</h5></b></p>
                        <a href="Boat Management System/reserve_form.php" class="btn btn-primary">Reserve Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Footer -->
    <footer class="text-center">
        <a class="up-arrow" href="gallery.php" data-toggle="tooltip" title="TO TOP">
            <span class="glyphicon glyphicon-chevron-up"></span>
        </a><br><br>
        <p> Copyright 2021-2022 by Vaishnavi. All Rights Reserved.</p>
    </footer>

</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</html>