<?php
include 'conn.php';

if(isset($_POST['fullname']) || isset($_POST['email']) || isset($_POST['password'])){
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $password = $_POST["password"];

 $sql = "INSERT INTO `sign_01` ( `fullname`, `email`, `password`, `created_at`)
     VALUES ('$fullname', '$email', '$password', CURRENT_TIMESTAMP)";

    $res = mysqli_query($conn,$sql);
   if($res==true){
//        echo 'successfully inserted';
    }else{
       echo 'sorry unsuccessfull';
   }
}
?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>signup</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="">
</head>

<body>

    <?php require 'nav.php' ?>


    <?php
    $sql = "select * from `sign_01`";
    $result = mysqli_query($conn, $sql);
    if ($result) {
       // echo "successfully";
        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['id'];
            $fullname = $row['fullname'];
            $email = $row['email'];
            $password = $row['password'];
            //echo $id;
        }
    }else{
        echo 'unsuccessfully';
    }
    ?>


    <div class="card" style="width: 70rem;">



        <div class="container my-4">
            <h1 class="text">Signup to our website</h1>
        </div>

        <form class="form-horizontal" method="post">
            <div class="form-group">
                <label class="control-label col-sm-2" for="fullname">FullName:</label>
                <div class="col-sm-5">
                    <input type="fullname" class="form-control" id="fullname" placeholder="Enter Full name" name="fullname"
                        required>

                </div>
            </div>
            <div class="form-group">

                <label class="control-label col-sm-2" for="email">Email:</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="email" placeholder="Enter email" name="email" required>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-sm-2" for="password">
                    Password:</label>
                <div class="col-sm-5">
                    <input type="password" class="form-control" id="password" placeholder="Enter password" name="password"
                        required>

                </div>
            </div>

            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-primary mb-3" name="sub">Submit</button>


                    <p>
                        Already a user ?<a href="login.php"><b>Log in</b><a>
                    </p>
                </div>
            </div>

        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js
/bootstrap.bundle.min.js"></script>
</body>

</html>