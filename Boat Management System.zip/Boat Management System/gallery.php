<!DOCTYPE html>
<html lang="en">

<head>
    <title> Online Boat Reservation</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
    <?php require 'nav.php' ?>
    <div style="margin-left:0;" class="container">
        <div class="panel panel-default">
            <div class="panel-body">
                <strong>
                    <h3>GALLERY</h3>
                </strong>
                <br />
                <br />
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/7.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/8.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/9.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/10.jpg" width="250" height="250" />
                </div>
                <br style="clear:both;" />
                <br />
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/11.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/12.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/13.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/14.jpg" width="250" height="250" />
                </div>
                <br style="clear:both;" />
                <br />
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/15.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/16.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/17.jpg" width="250" height="250" />
                </div>
                <div style="float:left; width:250px; height:250px; margin-left:20px;">
                    <img src="/Boat Management System/boat img/18.jpg" width="250" height="250" />
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>


    <!-- Footer -->
    <footer class="text-center">
        <a class="up-arrow" href="gallery.php" data-toggle="tooltip" title="TO TOP">
            <span class="glyphicon glyphicon-chevron-up"></span>
        </a><br><br>
        <p> Copyright 2021-2022 by Vaishnavi. All Rights Reserved.</p>
    </footer>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</html>